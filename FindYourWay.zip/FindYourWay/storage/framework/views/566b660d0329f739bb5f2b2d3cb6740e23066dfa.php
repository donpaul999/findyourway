<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Find Your way</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <!-- Favicons -->
  <link href="img/favicon.png" rel="icon">
  <link href="img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,400i,600,700|Raleway:300,400,400i,500,500i,700,800,900" rel="stylesheet">

  <!-- Bootstrap CSS File -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="lib/nivo-slider/css/nivo-slider.css" rel="stylesheet">
  <link href="lib/owlcarousel/owl.carousel.css" rel="stylesheet">
  <link href="lib/owlcarousel/owl.transitions.css" rel="stylesheet">
  <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="lib/animate/animate.min.css" rel="stylesheet">
  <link href="lib/venobox/venobox.css" rel="stylesheet">

  <!-- Nivo Slider Theme -->
  <link href="css/nivo-slider-theme.css" rel="stylesheet">

  <!-- Main Stylesheet File -->
  <link href="css/style.css" rel="stylesheet">

  <!-- Responsive Stylesheet File -->
  <link href="css/responsive.css" rel="stylesheet">

</head>

<body data-spy="scroll" data-target="#navbar-example">

  <div id="preloader"></div>

  <header>
    <!-- header-area start -->
    <div id="sticker" class="header-area">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-sm-12">

            <!-- Navigation -->
            <nav class="navbar navbar-default">
              <!-- Brand and toggle get grouped for better mobile display -->
              <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".bs-example-navbar-collapse-1" aria-expanded="false">
										<span class="sr-only">Toggle navigation</span>
										<span class="icon-bar"></span>
										<span class="icon-bar"></span>
										<span class="icon-bar"></span>
									</button>
                <!-- Brand -->
                <a class="navbar-brand page-scroll sticky-logo" href="index.html">
                  <h1>FindYourWay</h1>
                  <!-- Uncomment below if you prefer to use an image logo -->
                  <!-- <img src="img/logo.png" alt="" title=""> -->
								</a>
              </div>
              <!-- Collect the nav links, forms, and other content for toggling -->
              <div class="collapse navbar-collapse main-menu bs-example-navbar-collapse-1" id="navbar-example">
                  <ul class="nav navbar-nav navbar-right">
                      <li class="active">
                          <a class="page-scroll" href="#home">Acasa</a>
                      </li>
                      <li>
                          <a class="page-scroll" href="#about">Despre noi</a>
                      </li>
                      <li>
                          <a class="page-scroll" href="#services">Facultati</a>
                      </li>


                      <li>
                          <a class="page-scroll" href="#team">Echipa noastra</a>
                      </li>
                      <li>
                          <a class="page-scroll" href="#contact">Contact</a>
                      </li>
                  </ul>
              </div>
              <!-- navbar-collapse -->
            </nav>
            <!-- END: Navigation -->
          </div>
        </div>
      </div>
    </div>
    <!-- header-area end -->
  </header>
  <!-- header end -->

  <!-- Start Slider Area -->
  <div id="home" class="slider-area">
    <div class="bend niceties preview-2">
      <div id="ensign-nivoslider" class="slides">
        <img src="img/slider/home1.jpg" alt="" title="#slider-direction-1" />
        <img src="img/slider/home2.jpg" alt="" title="#slider-direction-2" />
        <img src="img/slider/home3.jpg" alt="" title="#slider-direction-3" />
      </div>

      <!-- direction 1 -->
      <div id="slider-direction-1" class="slider-direction slider-one">
        <div class="container">
          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="slider-content">
                    <!-- layer 1 -->

                    <div class="layer-1-2 wow slideInUp" data-wow-duration="2s" data-wow-delay=".1s">
                        <h1 class="title2">Find your way</h1>
                    </div>
                    <!-- layer 2 -->
                    <div class="layer-1-1 hidden-xs wow slideInDown" data-wow-duration="2s" data-wow-delay=".2s">
                        <h2 class="title1">Gaseste facultatea potrivita pentru tine chiar acum</h2>
                    </div>

                </div>
            </div>
          </div>
        </div>
      </div>

      <!-- direction 2 -->
      <div id="slider-direction-2" class="slider-direction slider-two">
        <div class="container">
          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="slider-content text-center">
                    <!-- layer 1 -->
                    <div class="layer-1-2 wow slideInUp" data-wow-duration="2s" data-wow-delay=".1s">
                        <h1 class="title2">Find your way</h1>
                    </div>

                    <!-- layer 2 -->
                    <div class="layer-1-1 hidden-xs wow slideInUp" data-wow-duration="2s" data-wow-delay=".2s">
                        <h2 class="title1">Vedem ce text adaugam aici :))</h2>
                    </div>
                </div>
            </div>
          </div>
        </div>
      </div>

      <!-- direction 3 -->
      <div id="slider-direction-3" class="slider-direction slider-two">
        <div class="container">
          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="slider-content">
                    <!-- layer 1 -->
                    <div class="layer-1-2 wow slideInUp" data-wow-duration="2s" data-wow-delay=".1s">
                        <h1 class="title2">Find your way</h1>
                    </div>
                    <!-- layer 2 -->
                    <div class="layer-1-1 hidden-xs wow slideInUp" data-wow-duration="2s" data-wow-delay=".2s">
                        <h2 class="title1">Si aici :))</h2>
                    </div>
                </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- End Slider Area -->

  <!-- Start About area -->
  <div id="about" class="about-area area-padding">
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="section-headline text-center">
            <h2>Despre noi</h2>
          </div>
        </div>
      </div>
      <div class="row">
        <!-- single-well start-->
        <div class="col-md-6 col-sm-6 col-xs-12">
          <div class="well-left">
            <div class="single-well">
              <a href="#">
								  <img src="img/about/1.jpg" alt="">
								</a>
            </div>
          </div>
        </div>
        <!-- single-well end-->
        <div class="col-md-6 col-sm-6 col-xs-12">
          <div class="well-middle">
            <div class="single-well">
              <a href="#">
                <h4 class="sec-head">Povestea noastra</h4>
              </a>
              <p>
                Paul , aici intervine povestea aceea pe care spuneai ca o ai pentru site :)) Sa vedem ce idee ai :))
              </p>
              <ul>
                <li>
                  <i class="fa fa-check"></i> Prima idee
                </li>
                <li>
                  <i class="fa fa-check"></i> A doua idee
                </li>
                <li>
                  <i class="fa fa-check"></i> A treia idee
                </li>
                <li>
                  <i class="fa fa-check"></i> A patra idee
                </li>
                <li>
                  <i class="fa fa-check"></i> A cincea idee
                </li>
              </ul>
            </div>
          </div>
        </div>
        <!-- End col-->
      </div>
    </div>
  </div>
  <!-- End About area -->

  <!-- Start Service area -->
  <div id="services" class="services-area area-padding">
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="section-headline services-head text-center">
            <h2>Gaseste facultatea potrivita</h2>
          </div>
        </div>
      </div>
      <div class="row text-center">
          <div class="services-contents">
              <div class="container box " style="opacity: 0.9;" id="facultate">
                  <br><br><br>
                  <div class="panel panel-default animated fadeInUp">
                      <div class="panel-body">
                          <div class="form-group">
                              <!--<h3 align="center" style="font-size:30px;">Gaseste facultatea potrivita pentru tine</h3><br />-->

                              <div class="form-group">
                                  <input type="text" name="materie" id="materie" class="form-control input-lg" placeholder="Introdu materia" style="font-size:15px;" />
                                  <div id="materiiList">
                                  </div>
                                  <br><br>
                                  <div class="table-responsive">

                                      <table class="table table-striped table-bordered" style="font-size:20px">
                                          <thead>
                                              <tr>
                                                  <th>Facultate</th>
                                                  <th>Universitate</th>
                                                  <th>Link</th>
                                                  <th>Locatie</th>
                                              </tr>
                                          </thead>
                                          <tbody></tbody>
                                      </table>
                                  </div>

                              </div>
                          </div>
                      </div>
                  </div>
              </div>
<?php echo e(csrf_field()); ?>

          </div>
      </div>
    </div>
  </div>
  <!-- End Service area -->




  <!-- Start team Area -->
  <div id="team" class="our-team-area area-padding">
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="section-headline text-center">
            <h2>Echipa noastra </h2>
          </div>
        </div>
      </div>
      <div class="row">
          <div class="team-top">
              <div class="col-md-3 col-sm-3 col-xs-12">
                  <div class="single-team-member">
                      <div class="team-img">
                          <a href="#">
                              <img src="img/team/paulColta.jpg" alt="">
                          </a>
                          <div class="team-social-icon text-center">
                              <ul>
                                  <li>
                                      <a href="https://www.facebook.com/stefanut999">
                                          <i class="fa fa-facebook"></i>
                                      </a>
                                  </li>
                                  <li>
                                      <a href="#">
                                          <i class="fa fa-linkedin"></i>
                                      </a>
                                  </li>
                                  <li>
                                      <a href="#">
                                          <i class="fa fa-twitter"></i>
                                      </a>
                                  </li>
                              </ul>
                          </div>
                      </div>
                      <div class="team-content text-center">
                          <h4>Paul-Ștefan Colța</h4>
                          <p>Seo</p>
                      </div>
                  </div>
              </div>
              <!-- End column -->
              <div class="col-md-3 col-sm-3 col-xs-12">
                  <div class="single-team-member">
                      <div class="team-img">
                          <a href="#">
                              <img src="img/team/smile.jpg" alt="">
                          </a>
                          <div class="team-social-icon text-center">
                              <ul>
                                  <li>
                                      <a href="https://www.facebook.com/simona.lazarescu.92">
                                          <i class="fa fa-facebook"></i>
                                      </a>
                                  </li>
                                  <li>
                                      <a href="https://www.linkedin.com/in/simona-l%C4%83z%C4%83rescu-a18b20173/">
                                          <i class="fa fa-linkedin"></i>
                                      </a>
                                  </li>
                                  <li>
                                      <a href="#">
                                          <i class="fa fa-twitter"></i>
                                      </a>
                                  </li>
                              </ul>
                          </div>
                      </div>
                      <div class="team-content text-center">
                          <h4>Simona Lăzărescu</h4>
                          <p>Full-Stack Developer</p>
                      </div>
                  </div>
              </div>
              <!-- End column -->
              <div class="col-md-3 col-sm-3 col-xs-12">
                  <div class="single-team-member">
                      <div class="team-img">
                          <a href="#">
                              <img src="img/team/AndreiFx.jpg" alt="">
                          </a>
                          <div class="team-social-icon text-center">
                              <ul>
                                  <li>
                                      <a href="https://www.facebook.com/andrei.covaci">
                                          <i class="fa fa-facebook"></i>
                                      </a>
                                  </li>
                                  <li>
                                      <a href="#">
                                          <i class="fa fa-linkedin"></i>
                                      </a>
                                  </li>
                                  <li>
                                      <a href="#">
                                          <i class="fa fa-twitter"></i>
                                      </a>
                                  </li>
                              </ul>
                          </div>
                      </div>
                      <div class="team-content text-center">
                          <h4>Andrei Fx</h4>
                          <p>Research Data Entry Specialist</p>
                      </div>
                  </div>
              </div>
              <!-- End column -->
              <div class="col-md-3 col-sm-3 col-xs-12">
                  <div class="single-team-member">
                      <div class="team-img">
                          <a href="#">
                              <img src="img/team/MihaiFeraru.jpg" alt="">
                          </a>
                          <div class="team-social-icon text-center">
                              <ul>
                                  <li>
                                      <a href="https://www.facebook.com/ferarumihail">
                                          <i class="fa fa-facebook"></i>
                                      </a>
                                  </li>
                                  <li>
                                      <a href="#">
                                          <i class="fa fa-linkedin"></i>
                                      </a>
                                  </li>
                                  <li>
                                      <a href="#">
                                          <i class="fa fa-twitter"></i>
                                      </a>
                                  </li>
                              </ul>
                          </div>
                      </div>
                      <div class="team-content text-center">
                          <h4>Mihai Feraru</h4>
                          <p>Nu stiu ce sa iti pun tie:)</p>
                      </div>
                  </div>
              </div>
              <div class="col-md-3 col-sm-3 col-xs-12">
                  <div class="single-team-member">
                      <div class="team-img">
                          <a href="#">
                              <img src="img/team/smile.jpg" alt="">
                          </a>
                          <div class="team-social-icon text-center">
                              <ul>
                                  <li>
                                      <a href="https://www.facebook.com/alexandru.cretu.754">
                                          <i class="fa fa-facebook"></i>
                                      </a>
                                  </li>
                                  <li>
                                      <a href="#">
                                          <i class="fa fa-linkedin"></i>
                                      </a>
                                  </li>
                                  <li>
                                      <a href="#">
                                          <i class="fa fa-twitter"></i>
                                      </a>
                                  </li>
                              </ul>
                          </div>
                      </div>
                      <div class="team-content text-center">
                          <h4>Alexandru Crețu</h4>
                          <p>Nu stiu ce sa iti pun tie:)</p>
                      </div>
                  </div>
              </div>
              <!-- End column -->
          </div>
      </div>
    </div>
  </div>
  <!-- End Team Area -->

  <!-- Start contact Area -->
  <div id="contact" class="contact-area" >
    <div class="contact-inner area-padding">
      <div class="contact-overly"></div>
      <div class="container ">
          <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                  <div class="section-headline text-center">
                      <h2>Contact</h2>
                  </div>
              </div>
          </div>
          <div class="row">
              <div class="col-md-6 col-sm-6 col-xs-12">
                  <img src="img/contact/contact.jpg" alt="">
              </div>
              <!-- Start  contact -->
              <div class="col-md-6 col-sm-6 col-xs-12">
                  <div class="form contact-form">

                      <form action="/postMail" method="post" role="form" class="contactForm">
                        <?php echo e(csrf_field()); ?>

                          <div class="form-group">
                              <input type="text" name="subject" class="form-control" placeholder="Introduceti subiectul"/>

                          </div>
                          <div class="form-group">
                              <input type="text" class="form-control" name="email" placeholder="Introduceti adresa de email" />

                          </div>

                          <div class="form-group">
                              <input class="form-control"  name="message" type="text"  placeholder="Introduceti mesajul" ></input>

                          </div>
                          <div class="text-center"><button type="submit">Trimite</button></div>
                      </form>
                  </div>
              </div>
              <!-- End Left contact -->
          </div>
      </div>
    </div>
  </div>
  <!-- End Contact Area -->

  <!-- Start Footer bottom Area -->
  <footer>
    <div class="footer-area-bottom">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="copyright text-center">
              <p>
                &copy; Copyright <strong>FindYourWay</strong>. Toate drepturile rezervate
              </p>
            </div>

          </div>
        </div>
      </div>
    </div>
  </footer>

  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>

  <!-- JavaScript Libraries -->
  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.min.js"></script>
  <script src="lib/owlcarousel/owl.carousel.min.js"></script>
  <script src="lib/venobox/venobox.min.js"></script>
  <script src="lib/knob/jquery.knob.js"></script>
  <script src="lib/wow/wow.min.js"></script>
  <script src="lib/parallax/parallax.js"></script>
  <script src="lib/easing/easing.min.js"></script>
  <script src="lib/nivo-slider/js/jquery.nivo.slider.js" type="text/javascript"></script>
  <script src="lib/appear/jquery.appear.js"></script>
  <script src="lib/isotope/isotope.pkgd.min.js"></script>



  <script src="js/main.js"></script>
</body>

</html>

<script>
$(document).ready(function(){

 $('#materie').keyup(function(){
        var query = $(this).val();
        if(query != '')
        {
         var _token = $('input[name="_token"]').val();
         $.ajax({
          url:"<?php echo e(route('index.fetch')); ?>",
          method:"POST",
          data:{query:query, _token:_token},
          success:function(data){
           $('#materiiList').fadeIn();
                    $('#materiiList').html(data);
          }
         });
        }
    });

    $(document).on('click', 'li', function(){
        $('#materie').val($(this).text());
        $('#materiiList').fadeOut();
    });

});

$(document).ready(function(){

 fetch_customer_data();

 function fetch_customer_data(query = '')
 {
  $.ajax({
   url:"<?php echo e(route('index.action')); ?>",
   method:'GET',
   data:{query:query},
   dataType:'json',
   success:function(data)
   {
    $('tbody').html(data.table_data);
   }
  })
 }

 $(document).on('keyup', '#materie', function(){
  var query = $(this).val();
  fetch_customer_data(query);
 });
});
</script>
</script>
