<h3>This is the new message</h3>
<p>Email:<?php echo e($email); ?></p>
<p>Subiect:<?php echo e($subject); ?></p>
<p>Mesaj:<?php echo e($bodyMessage); ?></p>
Echipa FindYourWay
