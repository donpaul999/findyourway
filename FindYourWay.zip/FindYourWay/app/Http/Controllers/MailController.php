<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Mail;

class mailController extends Controller
{
    //
    public function index(){
      return view('index');
    }

    public function post(Request $req){

      $req->validate([
        'subject'=>'required',
        'email'=>'required',
        'message'=>'required'
      ]);
      $data = [
        'subject'=>$req->subject,
        'email'=>$req->email,
        'bodyMessage'=>$req->message,

      ];

      Mail::send('mail.mail',$data,function($message) use ($data){
        $message->from($data['email']);
        $message->to('findyourway80@gmail.com');
        $message->subject($data['subject']);
      });
      $req->session()->flash('success', 'Email trimis cu success!!!');
      return redirect()->back();
    }
}
