<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class LiveSearch extends Controller
{
    function index()
    {
     return view('index');
    }

    function action(Request $request)
    {
     if($request->ajax())
     {
      $output = '';
      $query = $request->get('query');
      if($query != '')
      {
       $data = DB::table('facultati')
         ->where('materie', 'LIKE', "{$query}%")
         ->get();
       }
      $total_row = $data->count();
      if($total_row > 0)
      {
       foreach($data as $row)
       {
        $output .= '
        <tr>
         <td>'.$row->facultate.'</td>
         <td>'.$row->universitate.'</td>
         <td>'.$row->link.'</td>
         <td>'.$row->locatie.'</td>
        </tr>
        ';
       }
      }
      else
      {
       $output = '
       <tr>
        <td align="center" colspan="5">Nu s-au gasit facultati</td>
       </tr>
       ';
      }

      $data = array(
       'table_data'  => $output,
     );
      echo json_encode($data);
     }
    }
}
