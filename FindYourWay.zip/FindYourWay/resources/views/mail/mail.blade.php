<h3>This is the new message</h3>
<p>Email:{{$email}}</p>
<p>Subiect:{{$subject}}</p>
<p>Mesaj:{{$bodyMessage}}</p>
Echipa FindYourWay
